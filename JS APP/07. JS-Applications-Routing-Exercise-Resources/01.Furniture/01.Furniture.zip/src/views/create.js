import { html } from "../lib.js";

export function createPage() {
    console.log('create view')
}