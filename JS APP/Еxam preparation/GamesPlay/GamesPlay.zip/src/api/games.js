import * as api from '../api/api.js';

const endpoints = {
    'games': '/data/games?sortBy=_createdOn%20desc&distinct=category',
    'gameId': '/data/games/',
    'create': '/data/games',
    'delete': '/data/games/',
    'create': '/data/games/',
    'edit': '/data/games/',

}

export async function getGames() {
    return api.get(endpoints.games);
};


export async function getGameId(id) {
    return api.get(endpoints.gameId + id);
};


export async function create(data) {
    return api.post(endpoints.create, data);
};

export async function del(id) {
    return api.del(endpoints.delete + id);
};

export async function edit(id, data) {
    return api.put(endpoints.edit + id , data);
};