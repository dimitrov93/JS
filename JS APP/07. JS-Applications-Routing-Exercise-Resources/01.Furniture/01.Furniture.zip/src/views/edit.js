import { html } from "../lib.js";

export function editPage(ctx) {
    console.log('edit view', ctx.params.id)
}

