import { html } from "../lib.js";

export function detailsPage(ctx) {
    console.log('details view', ctx.params.id)
}